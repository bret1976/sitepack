const canvas = document.querySelector("#signalCanvas");
const ctx = canvas?.getContext("2d");
const glow = document.querySelector(".cursor-glow");
const signalOutput = document.querySelector("#signalOutput");
const ranges = [...document.querySelectorAll(".lab-panel input[type='range']")];
const hourButtons = [...document.querySelectorAll("[data-hours]")];
const hoursCount = document.querySelector("#hoursCount");
const consultingTotal = document.querySelector("#consultingTotal");
const portraitStage = document.querySelector(".portrait-stage");
const revealSections = [...document.querySelectorAll("#method, #signal-lab, #packages, #receipts")];
const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

let points = [];
let width = 0;
let height = 0;
let hours = 4;

function resizeCanvas() {
  if (!canvas || !ctx) return;
  const ratio = Math.min(window.devicePixelRatio || 1, 2);
  width = window.innerWidth;
  height = window.innerHeight;
  canvas.width = Math.floor(width * ratio);
  canvas.height = Math.floor(height * ratio);
  canvas.style.width = `${width}px`;
  canvas.style.height = `${height}px`;
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  points = Array.from({ length: Math.min(84, Math.floor(width / 16)) }, () => ({
    x: Math.random() * width,
    y: Math.random() * height,
    vx: (Math.random() - 0.5) * 0.35,
    vy: (Math.random() - 0.5) * 0.35,
    r: 1 + Math.random() * 2,
  }));
}

function drawSignal() {
  if (!canvas || !ctx) return;
  ctx.clearRect(0, 0, width, height);
  ctx.lineWidth = 1;

  for (const point of points) {
    point.x += point.vx;
    point.y += point.vy;

    if (point.x < -30) point.x = width + 30;
    if (point.x > width + 30) point.x = -30;
    if (point.y < -30) point.y = height + 30;
    if (point.y > height + 30) point.y = -30;
  }

  for (let i = 0; i < points.length; i += 1) {
    const a = points[i];
    ctx.beginPath();
    ctx.fillStyle = i % 3 === 0 ? "rgba(216,255,62,.7)" : "rgba(248,243,232,.45)";
    ctx.arc(a.x, a.y, a.r, 0, Math.PI * 2);
    ctx.fill();

    for (let j = i + 1; j < points.length; j += 1) {
      const b = points[j];
      const dist = Math.hypot(a.x - b.x, a.y - b.y);
      if (dist < 116) {
        ctx.beginPath();
        ctx.strokeStyle = `rgba(248,243,232,${0.12 - dist / 1200})`;
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.stroke();
      }
    }
  }

  requestAnimationFrame(drawSignal);
}

function updateSignalCopy() {
  if (!signalOutput || ranges.length < 3) return;
  const [publicSignal, aiLeverage, networkVelocity] = ranges.map((range) => Number(range.value));
  const average = (publicSignal + aiLeverage + networkVelocity) / 3;

  if (networkVelocity > 88 && publicSignal > 72) {
    signalOutput.value =
      "Your next advantage is not louder content. It is becoming the room's favorite shortcut to trust.";
  } else if (aiLeverage > 82) {
    signalOutput.value =
      "AI turns the blank page into an instrument. Cory turns the instrument into a business rhythm.";
  } else if (average > 70) {
    signalOutput.value =
      "Strong signal detected: package the proof, publish the thesis, invite the market into the story.";
  } else {
    signalOutput.value =
      "The signal is underpowered. Start with one belief, one audience, one offer, and one public proof loop.";
  }
}

function updateConsulting() {
  if (!hoursCount || !consultingTotal) return;
  hoursCount.textContent = hours;
  consultingTotal.textContent = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(hours * 1250);
}

window.addEventListener("resize", resizeCanvas);
window.addEventListener("pointermove", (event) => {
  if (glow) {
    glow.style.transform = `translate3d(${event.clientX - 176}px, ${event.clientY - 176}px, 0)`;
  }
});

if (portraitStage && !reduceMotion) {
  portraitStage.addEventListener("pointermove", (event) => {
    const rect = portraitStage.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width - 0.5;
    const y = (event.clientY - rect.top) / rect.height - 0.5;

    portraitStage.classList.add("is-distorting");
    portraitStage.style.setProperty("--tilt-x", `${x * 10}deg`);
    portraitStage.style.setProperty("--tilt-y", `${y * -8}deg`);
    portraitStage.style.setProperty("--rgb-x", `${x * 12}px`);
    portraitStage.style.setProperty("--rgb-y", `${y * 10}px`);
    portraitStage.style.setProperty("--warp", `${Math.abs(x * y) * 12}%`);
  });

  portraitStage.addEventListener("pointerleave", () => {
    portraitStage.classList.remove("is-distorting");
    portraitStage.style.setProperty("--tilt-x", "0deg");
    portraitStage.style.setProperty("--tilt-y", "0deg");
    portraitStage.style.setProperty("--rgb-x", "0px");
    portraitStage.style.setProperty("--rgb-y", "0px");
    portraitStage.style.setProperty("--warp", "0%");
  });
}

if (revealSections.length) {
  revealSections.forEach((section) => section.classList.add("reveal"));

  if (reduceMotion || !("IntersectionObserver" in window)) {
    revealSections.forEach((section) => section.classList.add("is-visible"));
  } else {
    const revealObserver = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            revealObserver.unobserve(entry.target);
          }
        }
      },
      { threshold: 0.16, rootMargin: "0px 0px -12% 0px" }
    );

    revealSections.forEach((section) => revealObserver.observe(section));
  }
}

ranges.forEach((range) => range.addEventListener("input", updateSignalCopy));

hourButtons.forEach((button) => {
  button.addEventListener("click", () => {
    hours = Math.max(1, Math.min(40, hours + Number(button.dataset.hours)));
    updateConsulting();
  });
});

resizeCanvas();
drawSignal();
updateSignalCopy();
updateConsulting();
