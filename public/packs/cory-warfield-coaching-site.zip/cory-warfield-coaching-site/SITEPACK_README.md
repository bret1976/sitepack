# Cory Warfield Coaching — SitePack

**Demo:** https://cory-warfield-coaching-site.vercel.app  
**Pack ID:** `cory-warfield-coaching-site`  
**Source:** repo:VegasCryptoAgent/cory-warfield-coaching-site  
**Stack notes:** Static HTML/CSS/JS coaching site

## What's included
- Full project source (sanitized — no live secrets)
- LICENSE.txt (personal + client work OK; no resale as competing packs)
- This README

## How to run
```bash
open index.html  # or: npx serve .
```

## Notes
- Replace any placeholder API keys / Firebase config with your own.
- Client/demo branding is illustrative — rebrand before shipping.
- Packaged for SitePack (sitepack). Motionsites-style browse → buy → unlock ZIP.
