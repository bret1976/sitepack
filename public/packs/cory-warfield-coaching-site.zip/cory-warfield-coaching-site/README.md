# Cory Warfield Coaching Site

Static executive coaching and consulting website concept for Cory Warfield.

## Deploy on Vercel

1. Import this GitHub repository in Vercel.
2. Use the default static settings.
3. No build command is required.
4. The output directory should be left blank.

## Local Preview

```bash
python3 -m http.server 4173
```

Then open `http://127.0.0.1:4173`.
