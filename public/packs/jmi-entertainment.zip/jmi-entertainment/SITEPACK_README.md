# JMI Entertainment — SitePack

**Demo:** https://jmi-entertainment.vercel.app  
**Pack ID:** `jmi-entertainment`  
**Source:** repo:bret1976/jmi-entertainment  
**Stack notes:** Next.js / Vite entertainment site

## What's included
- Full project source (sanitized — no live secrets)
- LICENSE.txt (personal + client work OK; no resale as competing packs)
- This README

## How to run
```bash
npm install && npm run dev
```

## Notes
- Replace any placeholder API keys / Firebase config with your own.
- Client/demo branding is illustrative — rebrand before shipping.
- Packaged for SitePack (sitepack). Motionsites-style browse → buy → unlock ZIP.
