import type { Metadata } from "next";
import { SiteFooter } from "../components/SiteFooter";
import { SiteHeader } from "../components/SiteHeader";

export const metadata: Metadata = {
  title: "Backstage",
  description:
    "How the Still Theory Studio brand film was built — paper lockups, dual shoots, and the engine under the paper.",
};

const engine = [
  {
    label: "PAPER",
    body: "Still Theory Studio is cut into the film frames themselves — logo, identity board, social desk — not stickers on top of another brand.",
  },
  {
    label: "FRAMES",
    body: "Seven scroll-scrubbed beats × landscape and portrait so the story never crops wrong on a phone.",
  },
  {
    label: "SCRUB",
    body: "Scroll drives frame index with double-buffered WebP layers — no janky video.currentTime seeking.",
  },
  {
    label: "CHAIN",
    body: "Seven scenes tied into one breath: logo → identity → software → social → crumple → desk → basket.",
  },
  {
    label: "GATE",
    body: "An intro loader unfolds the doodle page before the curtain rises.",
  },
  {
    label: "BRAND",
    body: "Wordmark in the paper: still theory / studio — same two-line lockup structure as a real identity board.",
  },
];

export default function BackstagePage() {
  return (
    <main className="subpage">
      <SiteHeader active="backstage" />
      <a className="skip skip-static" href="#backstage-body">
        skip to content <span>↓</span>
      </a>

      <div className="subpage-hero">
        <p className="footer-label">BACKSTAGE · STILL THEORY STUDIO</p>
        <h1>
          How was this
          <br />
          film shot?
        </h1>
        <p className="subpage-lede">
          No secrets: paper lockups with Still Theory Studio cut into the artwork, then frame-scrubbed into a
          film.
        </p>
      </div>

      <div id="backstage-body" className="backstage-body">
        <section className="backstage-block">
          <h2>The brand is in the paper</h2>
          <p>
            The logo beat, identity board and social desk were rebuilt so the letters spell Still Theory Studio
            as physical paper cuts — cream and orange kraft — not a UI label covering another studio&apos;s name.
          </p>
          <div className="frame-grid backstage-plates" style={{ marginTop: 28 }}>
            <figure>
              <img src="/assets/brand/logo-lockup.jpg" alt="Still Theory Studio logo lockup in paper" />
              <figcaption>logo lockup</figcaption>
            </figure>
            <figure>
              <img src="/assets/brand/id-board.jpg" alt="Still Theory Studio identity board in paper" />
              <figcaption>identity board</figcaption>
            </figure>
            <figure>
              <img src="/assets/brand/social-scene.jpg" alt="Still Theory Studio social scene in paper" />
              <figcaption>social desk</figcaption>
            </figure>
            <figure>
              <img src="/assets/og.png" alt="Still Theory Studio open graph paper art" />
              <figcaption>open graph</figcaption>
            </figure>
          </div>
        </section>

        <section className="backstage-block">
          <h2>The engine room</h2>
          <p>Everything running under the paper — one-line specs from the build.</p>
          <div className="engine-grid">
            {engine.map((item) => (
              <article key={item.label}>
                <p className="footer-label">{item.label}</p>
                <p>{item.body}</p>
              </article>
            ))}
          </div>
          <p className="studio-stats">it all began at a kid&apos;s desk — Still Theory Studio</p>
          <a className="back-to-film" href="/">
            back to the film →
          </a>
        </section>
      </div>

      <SiteFooter />
    </main>
  );
}
