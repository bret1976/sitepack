import type { Metadata } from "next";
import { SiteFooter } from "../components/SiteFooter";
import { SiteHeader } from "../components/SiteHeader";

export const metadata: Metadata = {
  title: "Work",
  description: "Selected work from Still Theory Studio — brands, products and paper-born experiences.",
};

const projects = [
  {
    name: "Kali Beach",
    year: "2025",
    tags: "Beach Club · Entertainment",
    note: "A sun-bleached identity and booking surface for a coastal club.",
    tone: "orange",
    image: "/assets/brand/social-scene.jpg",
  },
  {
    name: "Beşantaş",
    year: "2025",
    tags: "Construction · Concrete & Roofing",
    note: "Industrial weight, clean type — a builder brand that still feels hand-cut.",
    tone: "kraft",
    image: "/assets/brand/id-board.jpg",
  },
  {
    name: "Mendel’s",
    year: "2024",
    tags: "Café · Chocolatier",
    note: "Warm paper packaging and a storefront site that tastes like cocoa.",
    tone: "cream",
    image: "/assets/intro/paper-doodles.webp",
  },
  {
    name: "Still Theory Studio",
    year: "2026",
    tags: "Group Brand · In-house",
    note: "Our own mark: eclipse, kraft, and a film that starts on a kid’s desk.",
    tone: "ink",
    image: "/assets/brand/logo-lockup.jpg",
  },
];

export default function WorkPage() {
  return (
    <main className="subpage">
      <SiteHeader active="work" />
      <a className="skip skip-static" href="#selected-work">
        skip to content <span>↓</span>
      </a>

      <div className="subpage-hero">
        <p className="footer-label">SELECTED WORK</p>
        <h1>Work</h1>
        <p className="subpage-lede">
          Brands, products and interfaces cut from the same sheet of paper — each one drawn first at Still
          Theory Studio, then made real.
        </p>
      </div>

      <section id="selected-work" className="work-grid work-grid-photo">
        {projects.map((project, index) => (
          <article className={`work-card tone-${project.tone}`} key={project.name}>
            <div className="work-card-photo">
              <img src={project.image} alt={`${project.name} — Still Theory Studio`} />
            </div>
            <div className="work-card-meta">
              <small>
                {project.year} · {project.tags}
              </small>
              <span>0{index + 1}</span>
            </div>
            <h2>{project.name}</h2>
            <p>{project.note}</p>
            <a href={`mailto:hello@stilltheory.studio?subject=${encodeURIComponent(`About ${project.name}`)}`}>
              view project →
            </a>
          </article>
        ))}
      </section>

      <section className="subpage-cta">
        <div>
          <p className="footer-label">NEXT</p>
          <h2>Got a brand that still lives on a napkin?</h2>
          <p>Still Theory Studio turns paper ideas into living work.</p>
        </div>
        <a className="cta-mail" href="mailto:hello@stilltheory.studio">
          hello@stilltheory.studio →
        </a>
      </section>

      <SiteFooter />
    </main>
  );
}
