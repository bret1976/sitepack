import type { Metadata } from "next";
import { SiteFooter } from "../components/SiteFooter";
import { SiteHeader } from "../components/SiteHeader";

export const metadata: Metadata = {
  title: "Studio",
  description:
    "Still Theory Studio workshop — ideas begin on paper. We draw, make and grow brands, software and social.",
};

const steps = [
  {
    num: "01",
    title: "DRAW",
    body: "Every job starts as a sketch. We open paper on the table, not slides in a meeting; an idea breathes in lines first. A wrong line is still a line — we crumple it and start again.",
  },
  {
    num: "02",
    title: "MAKE",
    body: "Design and code are made at the same table. The designer reads the code, the developer reads the sketch; there is no handover in between. What you see on screen is the very thing we drew.",
  },
  {
    num: "03",
    title: "GROW",
    body: "Going live is a beginning, not an end. We watch, measure and grow the work in production — an idea that left the paper stays alive by being used.",
  },
];

const services = ["brand identity", "web experiences", "product interfaces", "software"];

const frames = [
  { src: "/assets/brand/logo-lockup.jpg", caption: "still theory studio — paper lockup" },
  { src: "/assets/brand/id-board.jpg", caption: "identity board from the desk" },
  { src: "/assets/brand/social-scene.jpg", caption: "social, cut from kraft" },
  { src: "/assets/reference-scenes/basket.webp", caption: "and the ball finds the bin" },
];

export default function StudioPage() {
  return (
    <main className="subpage">
      <SiteHeader active="studio" />
      <a className="skip skip-static" href="#workshop">
        skip to content <span>↓</span>
      </a>

      <div className="subpage-hero studio-hero-with-paper">
        <p className="footer-label">WORKSHOP · STILL THEORY STUDIO</p>
        <h1>
          Ideas begin
          <br />
          on paper.
        </h1>
        <p className="subpage-lede">We take them from there and turn them into living work.</p>
        <img
          className="studio-hero-paper"
          src="/assets/brand/logo-lockup.jpg"
          alt="Still Theory Studio — still theory studio cut from paper"
        />
      </div>

      <section id="workshop" className="studio-steps">
        {steps.map((step) => (
          <article className="studio-step" key={step.num}>
            <p className="footer-label">
              {step.num} / {step.title}
            </p>
            <h2>
              {step.num} / {step.title}
            </h2>
            <p>{step.body}</p>
          </article>
        ))}
      </section>

      <section className="studio-frames">
        <h2>Frames from the desk</h2>
        <div className="frame-grid">
          {frames.map((frame) => (
            <figure key={frame.caption}>
              <img src={frame.src} alt={frame.caption} />
              <figcaption>{frame.caption}</figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className="studio-services">
        <h2>What we do</h2>
        <ul>
          {services.map((service, index) => (
            <li key={service}>
              <b>0{index + 1}</b>
              <span>{service}</span>
            </li>
          ))}
        </ul>
        <p className="studio-stats">4 live projects · 2 languages · 1 desk · Still Theory Studio</p>
      </section>

      <section className="subpage-cta studio-together">
        <div>
          <p className="footer-label">TOGETHER</p>
          <h2>there&apos;s room at the table</h2>
          <p>open for new projects</p>
        </div>
        <a className="cta-mail" href="mailto:hello@stilltheory.studio">
          hello@stilltheory.studio →
        </a>
        <p className="studio-location">Los Angeles · Everywhere · Instagram · LinkedIn</p>
        <p className="studio-backstage-link">
          This desk has a backstage, too. <a href="/backstage">go backstage →</a>
        </p>
      </section>

      <SiteFooter />
    </main>
  );
}
