import type { Metadata } from "next";
import { SiteFooter } from "../../components/SiteFooter";
import { SiteHeader } from "../../components/SiteHeader";

export const metadata: Metadata = {
  title: "Privacy Notice",
  description: "Privacy notice for Still Theory Studio.",
};

export default function PrivacyPage() {
  return (
    <main className="subpage legal-page">
      <SiteHeader />
      <a className="skip skip-static" href="#legal-body">
        skip to content <span>↓</span>
      </a>

      <article id="legal-body" className="legal-doc">
        <h1>Privacy Notice</h1>
        <p className="legal-updated">Last updated: July 23, 2026</p>

        <h2>Data Controller</h2>
        <p>
          This site is operated by Still Theory Studio. For anything regarding your personal data, reach us at{" "}
          <a href="mailto:hello@stilltheory.studio">hello@stilltheory.studio</a>.
        </p>

        <h2>What We Process</h2>
        <p>
          When you email us: your name, email address and the content of your message — processed solely to
          carry out the correspondence and answer your request.
        </p>
        <p>
          Preferences stored in your browser (if you enable sound or language choices) live in your device’s
          localStorage; they are never sent to us or to any third party for advertising.
        </p>

        <h2>Analytics & Tracking</h2>
        <p>
          This site uses no analytics or tracking tools by default. Your visit is not profiled for marketing.
        </p>

        <h2>Cookies</h2>
        <p>
          Essential preferences only (for example a language cookie if enabled). They serve no advertising or
          profiling purpose.
        </p>

        <h2>Retention & Sharing</h2>
        <p>
          Email correspondence is kept with our email provider for as long as the exchange requires. Your data
          is never sold to third parties for marketing.
        </p>

        <h2>Your Rights</h2>
        <p>
          You may request access to, correction or deletion of your data, and object to its processing.
          Contact: <a href="mailto:hello@stilltheory.studio">hello@stilltheory.studio</a>.
        </p>
      </article>

      <SiteFooter />
    </main>
  );
}
