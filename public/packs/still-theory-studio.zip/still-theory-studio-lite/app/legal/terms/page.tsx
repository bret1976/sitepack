import type { Metadata } from "next";
import { SiteFooter } from "../../components/SiteFooter";
import { SiteHeader } from "../../components/SiteHeader";

export const metadata: Metadata = {
  title: "Terms of Use",
  description: "Terms of use for Still Theory Studio.",
};

export default function TermsPage() {
  return (
    <main className="subpage legal-page">
      <SiteHeader />
      <a className="skip skip-static" href="#legal-body">
        skip to content <span>↓</span>
      </a>

      <article id="legal-body" className="legal-doc">
        <h1>Terms of Use</h1>
        <p className="legal-updated">Last updated: July 23, 2026</p>

        <h2>About this site</h2>
        <p>
          This website is operated by Still Theory Studio. By using the site you agree to these terms. If you
          do not agree, please do not use the site.
        </p>

        <h2>Content</h2>
        <p>
          All text, film, imagery, marks and design on this site are the property of Still Theory Studio or
          its partners, unless otherwise noted. You may not copy, redistribute or reuse them without written
          permission.
        </p>

        <h2>Projects & proposals</h2>
        <p>
          Project discussions started by email or social channels are confidential to the extent agreed in
          writing. Nothing on this site constitutes a binding offer until confirmed in a signed agreement.
        </p>

        <h2>No warranties</h2>
        <p>
          The site is provided “as is.” We make reasonable efforts to keep it available and accurate, but we
          do not guarantee uninterrupted access or that every detail will always be current.
        </p>

        <h2>Contact</h2>
        <p>
          Questions about these terms:{" "}
          <a href="mailto:hello@stilltheory.studio">hello@stilltheory.studio</a>.
        </p>
      </article>

      <SiteFooter />
    </main>
  );
}
