"use client";

import { CSSProperties, useCallback, useEffect, useMemo, useRef, useState } from "react";

/**
 * Still Theory Studio — scroll film.
 * All-intra H.264 scrub videos (every frame is a keyframe) + full blob preload.
 * Scroll drives video.currentTime with a 1:1 rAF loop — no per-frame HTTP.
 */

type ScrubMeta = {
  frames: number;
  duration: number;
  src: string;
};

const scenes = [
  {
    id: "01-logo",
    label: "Logo",
    eyebrow: "STILL THEORY STUDIO",
    titleWords: ["IDEAS", "BEGIN", "ON", "PAPER"],
    body: "We cut, fold and rebuild brands.",
    tone: "ink",
    frames: 193,
  },
  {
    id: "02-kimlik",
    label: "Identity",
    eyebrow: "01 / BRAND IDENTITY",
    titleWords: ["EVERY", "PIECE", "OF", "YOUR", "BRAND"],
    body: "Logo, color, typography, business cards — designed by one hand, in one visual language.",
    tone: "cream",
    frames: 193,
  },
  {
    id: "03-yazilim",
    label: "Software",
    eyebrow: "02 / SOFTWARE",
    titleWords: ["FROM", "IDEA", "TO", "WORKING", "PRODUCT"],
    body: "Web and mobile apps — fast, scalable, entirely yours.",
    tone: "kraft",
    frames: 193,
  },
  {
    id: "04-sosyal",
    label: "Social",
    eyebrow: "03 / SOCIAL MEDIA",
    titleWords: ["YOUR", "BRAND", "SPEAKS", "EVERY", "DAY"],
    body: "We design what it says and how it looks — content, management, growth.",
    tone: "cream",
    frames: 193,
  },
  {
    id: "05-burusma",
    label: "Crumple",
    eyebrow: "",
    titleWords: ["FROM", "PAPER", "TO", "REAL."],
    body: "",
    tone: "none",
    frames: 193,
  },
  {
    id: "06-cocuk",
    label: "Child",
    eyebrow: "",
    titleWords: ["EVERY", "BIG", "IDEA", "STARTS", "AT", "A", "CHILD'S", "DESK"],
    body: "",
    tone: "ink",
    frames: 193,
  },
  {
    id: "07-basket",
    label: "Basket",
    eyebrow: "",
    titleWords: ["CREATIVITY", "FOR", "NEXT", "GENERATIONS"],
    body: "",
    tone: "none",
    frames: 145,
  },
];

const works = [
  { name: "Kali Beach", kind: "WEB", href: "/work" },
  { name: "Beşantaş", kind: "WEB", href: "/work" },
  { name: "Mendel’s", kind: "WEB", href: "/work" },
  { name: "Still Theory Studio", kind: "GROUP BRAND", href: "/work" },
];

const FPS = 30;

function isPortrait() {
  return typeof window !== "undefined" && window.matchMedia("(max-width: 768px) and (orientation: portrait)").matches;
}

function defaultSrc(sceneId: string, portrait: boolean) {
  return `/assets/film/scrub/${portrait ? "portrait" : "landscape"}/${sceneId}.mp4`;
}

export default function Home() {
  const filmRef = useRef<HTMLElement>(null);
  const videoRefs = useRef<(HTMLVideoElement | null)[]>([]);
  const blobUrlsRef = useRef<string[]>([]);
  const progressTarget = useRef(0);
  const progressDisplay = useRef(0);
  const lastSeekKey = useRef("");
  const scrollListening = useRef(false);
  const dimTimer = useRef<number | null>(null);
  const rafLoop = useRef(0);
  const audioRef = useRef<{ ctx: AudioContext; gain: GainNode } | null>(null);
  const metaRef = useRef<Record<string, ScrubMeta>>({});

  const [load, setLoad] = useState(0);
  const [introReady, setIntroReady] = useState(false);
  const [entered, setEntered] = useState(false);
  const [active, setActive] = useState(0);
  const [local, setLocal] = useState(0);
  const [sound, setSound] = useState(false);
  const [ritual, setRitual] = useState(false);
  const [barDim, setBarDim] = useState(false);
  const [portrait, setPortrait] = useState(false);
  const [videosReady, setVideosReady] = useState(false);

  const sceneFrames = useMemo(
    () =>
      scenes.map((s) => {
        const m = metaRef.current[s.id];
        return m?.frames || s.frames;
      }),
    // recompute when videos ready / portrait flips (meta filled)
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [videosReady, portrait],
  );

  const totalFrames = useMemo(() => sceneFrames.reduce((a, b) => a + b, 0), [sceneFrames]);

  const resolveFrame = useCallback(
    (globalFrame: number) => {
      let remaining = Math.max(0, Math.min(Math.max(0, totalFrames - 1), globalFrame));
      for (let i = 0; i < scenes.length; i += 1) {
        const count = sceneFrames[i] || scenes[i].frames;
        if (remaining < count) {
          return {
            sceneIndex: i,
            frame: remaining + 1,
            local: remaining / Math.max(1, count - 1),
            frames: count,
          };
        }
        remaining -= count;
      }
      const last = scenes.length - 1;
      const count = sceneFrames[last] || scenes[last].frames;
      return { sceneIndex: last, frame: count, local: 1, frames: count };
    },
    [sceneFrames, totalFrames],
  );

  const uiSceneRef = useRef(0);
  const uiLocalRef = useRef(0);
  const barDimOnRef = useRef(false);

  const seekVideos = useCallback(
    (progress: number) => {
      if (totalFrames < 2) return;
      const exact = progress * (totalFrames - 1);
      const resolved = resolveFrame(exact);
      const scene = scenes[resolved.sceneIndex];
      const meta = metaRef.current[scene.id];
      const frames = meta?.frames || resolved.frames;
      const duration = meta?.duration || frames / FPS;
      // frame index 0-based within scene
      const frameIndex = Math.min(frames - 1, Math.max(0, Math.round(resolved.local * (frames - 1))));
      const time = Math.min(duration - 0.001, Math.max(0, frameIndex / FPS));

      const key = `${resolved.sceneIndex}:${frameIndex}`;
      if (lastSeekKey.current !== key) {
        lastSeekKey.current = key;
        const vid = videoRefs.current[resolved.sceneIndex];
        if (vid && Number.isFinite(time)) {
          // All-intra + full blob: seek is free — hard-set every frame change
          try {
            if (Math.abs(vid.currentTime - time) >= 1 / FPS - 0.001) {
              vid.currentTime = time;
            }
          } catch {
            /* ignore mid-load seeks */
          }
        }
      }

      // Visibility via DOM only — never wait on React for the film layer
      if (uiSceneRef.current !== resolved.sceneIndex) {
        for (let i = 0; i < scenes.length; i += 1) {
          const v = videoRefs.current[i];
          if (!v) continue;
          const on = i === resolved.sceneIndex;
          v.style.opacity = on ? "1" : "0";
          v.style.zIndex = on ? "2" : "1";
          if (on && !v.paused) v.pause();
        }
        uiSceneRef.current = resolved.sceneIndex;
        setActive(resolved.sceneIndex);
      }

      // Captions / rail — throttle React to ~3% steps
      if (Math.abs(uiLocalRef.current - resolved.local) > 0.03) {
        uiLocalRef.current = resolved.local;
        setLocal(resolved.local);
      }
    },
    [resolveFrame, totalFrames],
  );

  // Portrait / orientation
  useEffect(() => {
    const update = () => setPortrait(isPortrait());
    update();
    window.addEventListener("resize", update);
    window.addEventListener("orientationchange", update);
    return () => {
      window.removeEventListener("resize", update);
      window.removeEventListener("orientationchange", update);
    };
  }, []);

  // Full blob preload of all-intra scrub videos — network only during intro
  useEffect(() => {
    let cancelled = false;
    const blobUrls: string[] = [];

    const run = async () => {
      setVideosReady(false);
      setIntroReady(false);
      setLoad(0);
      lastSeekKey.current = "";

      // revoke previous blobs
      for (const u of blobUrlsRef.current) URL.revokeObjectURL(u);
      blobUrlsRef.current = [];

      // load scrub manifest if present
      try {
        const man = await fetch("/assets/film/scrub/manifest.json").then((r) => (r.ok ? r.json() : null));
        if (man) {
          const key = isPortrait() ? "portrait" : "landscape";
          const pack = man[key] || man.landscape || {};
          metaRef.current = pack;
        }
      } catch {
        /* defaults */
      }

      const orientation = isPortrait() ? "portrait" : "landscape";
      const sources = scenes.map((s) => {
        const m = metaRef.current[s.id];
        return m?.src || defaultSrc(s.id, orientation === "portrait");
      });

      // Parallel fetch with progress
      const totalBytesEstimate = sources.length; // fallback weight per file
      const weights = sources.map(() => 1);
      const loaded = sources.map(() => 0);

      const report = () => {
        const sumW = weights.reduce((a, b) => a + b, 0) || 1;
        const sumL = loaded.reduce((a, b, i) => a + b * weights[i], 0);
        const pct = Math.min(99, Math.round((sumL / sumW) * 100));
        setLoad(pct);
      };

      const results = await Promise.all(
        sources.map(async (src, i) => {
          try {
            const res = await fetch(src, { cache: "force-cache" });
            if (!res.ok) throw new Error(`fetch ${src}`);
            const cl = res.headers.get("content-length");
            if (cl) weights[i] = Math.max(1, parseInt(cl, 10));

            // Stream if possible for smooth %; else blob
            if (res.body && cl) {
              const reader = res.body.getReader();
              const chunks: Uint8Array[] = [];
              let received = 0;
              const total = parseInt(cl, 10);
              for (;;) {
                const { done, value } = await reader.read();
                if (done) break;
                if (value) {
                  chunks.push(value);
                  received += value.length;
                  loaded[i] = Math.min(1, received / total);
                  if (!cancelled) report();
                }
              }
              const blob = new Blob(chunks as BlobPart[], { type: "video/mp4" });
              loaded[i] = 1;
              if (!cancelled) report();
              return blob;
            }

            const blob = await res.blob();
            loaded[i] = 1;
            if (!cancelled) report();
            return blob;
          } catch {
            loaded[i] = 1;
            if (!cancelled) report();
            return null;
          }
        }),
      );

      if (cancelled) return;

      // Attach to video elements
      for (let i = 0; i < scenes.length; i += 1) {
        const video = videoRefs.current[i];
        if (!video) continue;
        video.pause();
        video.muted = true;
        video.playsInline = true;
        video.preload = "auto";
        video.setAttribute("playsinline", "");
        video.setAttribute("webkit-playsinline", "");
        video.setAttribute("muted", "");

        const blob = results[i];
        if (blob) {
          const url = URL.createObjectURL(blob);
          blobUrls.push(url);
          video.src = url;
        } else {
          // network fallback path (still all-intra file)
          video.src = sources[i];
        }

        await new Promise<void>((resolve) => {
          const done = () => {
            video.removeEventListener("loadeddata", done);
            video.removeEventListener("error", done);
            resolve();
          };
          if (video.readyState >= 2) {
            resolve();
            return;
          }
          video.addEventListener("loadeddata", done);
          video.addEventListener("error", done);
          video.load();
        });

        // Decode first frame
        try {
          video.currentTime = 0;
        } catch {
          /* */
        }

        // Fill meta duration from element if missing
        if (!metaRef.current[scenes[i].id]) {
          metaRef.current[scenes[i].id] = {
            frames: scenes[i].frames,
            duration: video.duration && Number.isFinite(video.duration) ? video.duration : scenes[i].frames / FPS,
            src: sources[i],
          };
        } else if (video.duration && Number.isFinite(video.duration)) {
          metaRef.current[scenes[i].id].duration = video.duration;
        }
      }

      if (cancelled) return;
      blobUrlsRef.current = blobUrls;
      setVideosReady(true);
      setLoad(100);
      // paint frame 0
      seekVideos(0);
      window.setTimeout(() => {
        if (!cancelled) setIntroReady(true);
      }, 120);
    };

    void run();

    return () => {
      cancelled = true;
      for (const u of blobUrls) URL.revokeObjectURL(u);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [portrait]);

  // Continuous rAF: follow scroll target 1:1 (buffered video = no catch-up lag needed)
  useEffect(() => {
    if (!videosReady) return;

    const readProgress = () => {
      const film = filmRef.current;
      if (!film) return 0;
      const rect = film.getBoundingClientRect();
      const distance = Math.max(1, rect.height - window.innerHeight);
      return Math.max(0, Math.min(0.9999, -rect.top / distance));
    };

    const tick = () => {
      const target = scrollListening.current ? readProgress() : progressTarget.current;
      progressTarget.current = target;

      // Snap 1:1 — all-intra + blob means seek is free; lag would feel sticky
      const display = target;
      progressDisplay.current = display;
      seekVideos(display);

      if (display > 0.01 && display < 0.99) {
        if (!barDimOnRef.current) {
          barDimOnRef.current = true;
          setBarDim(true);
        }
        if (dimTimer.current) window.clearTimeout(dimTimer.current);
        dimTimer.current = window.setTimeout(() => {
          barDimOnRef.current = false;
          setBarDim(false);
        }, 700);
      }

      rafLoop.current = requestAnimationFrame(tick);
    };

    const onScroll = () => {
      scrollListening.current = true;
      progressTarget.current = readProgress();
    };

    scrollListening.current = true;
    progressTarget.current = readProgress();
    rafLoop.current = requestAnimationFrame(tick);
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    window.addEventListener("wheel", onScroll, { passive: true });
    window.addEventListener("touchmove", onScroll, { passive: true });

    return () => {
      cancelAnimationFrame(rafLoop.current);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      window.removeEventListener("wheel", onScroll);
      window.removeEventListener("touchmove", onScroll);
      if (dimTimer.current) window.clearTimeout(dimTimer.current);
    };
  }, [videosReady, seekVideos]);

  const enter = () => {
    if (!introReady) return;
    setEntered(true);
    window.setTimeout(() => {
      const film = filmRef.current;
      if (!film) return;
      seekVideos(0);
      const top = window.scrollY + film.getBoundingClientRect().top;
      window.scrollTo({ top: top + 2, behavior: "auto" });
    }, 40);
  };

  const toggleSound = async () => {
    if (!audioRef.current) {
      const ctx = new AudioContext();
      const gain = ctx.createGain();
      const osc = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();
      osc.type = "triangle";
      osc.frequency.value = 72;
      filter.type = "lowpass";
      filter.frequency.value = 240;
      gain.gain.value = 0;
      osc.connect(filter).connect(gain).connect(ctx.destination);
      osc.start();
      audioRef.current = { ctx, gain };
    }
    const next = !sound;
    await audioRef.current.ctx.resume();
    audioRef.current.gain.gain.setTargetAtTime(next ? 0.02 : 0, audioRef.current.ctx.currentTime, 0.18);
    setSound(next);
  };

  const seek = (index: number) => {
    const film = filmRef.current;
    if (!film || totalFrames < 2) return;
    let before = 0;
    for (let i = 0; i < index; i += 1) before += sceneFrames[i] || scenes[i].frames;
    const progress = before / Math.max(1, totalFrames - 1);
    const top = window.scrollY + film.getBoundingClientRect().top;
    const travel = film.offsetHeight - window.innerHeight;
    window.scrollTo({ top: top + travel * progress, behavior: "auto" });
  };

  const sceneStyle = { "--p": local.toFixed(3) } as CSSProperties;
  const introFrame = String(Math.min(29, Math.floor((load / 100) * 30))).padStart(3, "0");

  return (
    <main>
      <div
        className={`intro ${introReady ? "is-ready" : ""} ${entered ? "is-gone" : ""}`}
        onWheel={enter}
        onTouchMove={enter}
      >
        <picture className="intro-unfold">
          <source
            media="(max-width: 768px) and (orientation: portrait)"
            srcSet={`/assets/intro/frames-portrait/intro-${introFrame}.webp`}
          />
          <img src={`/assets/intro/frames/intro-${introFrame}.webp`} alt="" />
        </picture>
        <div className="intro-pct">
          {load}
          <i>%</i>
        </div>
        <div className="intro-reveal">
          <picture className="intro-poster">
            <source
              media="(max-width: 768px) and (orientation: portrait)"
              srcSet="/assets/intro/paper-doodles-portrait.webp"
            />
            <img src="/assets/intro/paper-doodles.webp" alt="" />
          </picture>
          <div className="intro-copy">
            <img src="/assets/intro/headline.webp" alt="Dreams are drawn first — Still Theory Studio" />
            <p>we were all that kid once</p>
          </div>
          <button type="button" onClick={enter}>
            Scroll <span>↓</span>
          </button>
        </div>
      </div>

      <a className="skip" href="#paper-cursor">
        skip film <span>↓</span>
      </a>

      <header className={`topbar ${barDim ? "is-dim" : ""}`}>
        <a className="topmark" href="#film" aria-label="Still Theory Studio">
          <span className="eclipse" />
          <b>still theory studio</b>
        </a>
        <nav aria-label="site navigation">
          <a className="on" href="#film">
            film
          </a>
          <i>·</i>
          <a href="/work">work</a>
          <i>·</i>
          <a href="/studio">studio</a>
          <i>·</i>
          <a href="/backstage">backstage</a>
          <i>·</i>
          <span className="langs">
            <b>en</b>
            <em>tr</em>
          </span>
        </nav>
      </header>

      <button
        className={`sound-toggle ${sound ? "is-on" : ""}`}
        type="button"
        onClick={toggleSound}
        aria-label="Toggle sound"
      >
        <span className="speaker">◖</span>
        <span className="waves">
          <i />
          <i />
          <i />
        </span>
        <b>{sound ? "sound on" : "sound off"}</b>
      </button>

      <section ref={filmRef} id="film" className="film" aria-label="Still Theory Studio brand film">
        <div className="film-stage" style={sceneStyle}>
          {scenes.map((scene, index) => (
            <video
              key={`${scene.id}-${portrait ? "p" : "l"}`}
              ref={(el) => {
                videoRefs.current[index] = el;
              }}
              className="film-canvas-el film-scrub-video"
              muted
              playsInline
              preload="auto"
              aria-hidden={active !== index}
              style={{ opacity: active === index ? 1 : 0, zIndex: active === index ? 2 : 1 }}
            />
          ))}

          {scenes.map((scene, index) => (
            <div
              className={`scene film-beat beat-${index} ${active === index ? "is-on" : ""}`}
              key={scene.id}
              aria-hidden={active !== index}
            >
              {index < 4 && (
                <div className={`collage-caption tone-${scene.tone} cap-${index}`}>
                  <p className="cap-eyebrow">{scene.eyebrow}</p>
                  <div className="cap-words">
                    {scene.titleWords.map((word) => (
                      <span key={word}>{word}</span>
                    ))}
                  </div>
                  {scene.body && <b className="cap-body">{scene.body}</b>}
                </div>
              )}
              {index === 4 && (
                <div className="crumple-word">
                  FROM PAPER
                  <br />
                  <b>TO REAL.</b>
                </div>
              )}
              {index === 5 && (
                <div className="child-title">
                  Every big idea starts
                  <br />
                  at a child&apos;s desk
                </div>
              )}
              {index === 6 && (
                <div className="final-words">
                  <span>CREATIVITY</span>
                  <span>TECHNOLOGY</span>
                  <i>FOR</i>
                  <b>
                    NEXT
                    <br />
                    GENERATIONS
                  </b>
                </div>
              )}
            </div>
          ))}

          <nav className="scene-rail" aria-label="Film scenes">
            <div className="scene-rail-track">
              <div
                className="scene-rail-fill"
                style={{ height: `${((active + local) / scenes.length) * 100}%` }}
              />
            </div>
            {scenes.map((scene, index) => (
              <button
                key={scene.label}
                type="button"
                className={active === index ? "is-active" : ""}
                onClick={() => seek(index)}
              >
                <i />
                <span>{scene.label}</span>
              </button>
            ))}
          </nav>
        </div>
      </section>

      <footer id="paper-cursor" className={ritual ? "ritual" : ""}>
        <section className="footer-hero">
          <div className="footer-headline">
            <span>CREATIVITY FOR</span>
            <b>NEXT GENERATIONS</b>
          </div>
          <p>
            Ideas begin on paper.
            <br />
            The good ones keep moving.
          </p>
        </section>

        <section id="works" className="selected-work">
          <div className="footer-label">SELECTED WORK</div>
          <div className="work-list">
            {works.map((work) => (
              <a href={work.href} key={work.name}>
                <small>{work.kind}</small>
                <b>{work.name}</b>
                <span>→</span>
              </a>
            ))}
          </div>
          <div className="works-links">
            <a href="/work">SEE ALL →</a>
            <a href="#connect">@stilltheorystudio</a>
          </div>
        </section>

        <div className="footer-cards">
          <section className="brand-card brand-card-photo">
            <div className="footer-label">BRAND</div>
            <img className="brand-paper-shot" src="/assets/brand/logo-lockup.jpg" alt="Still Theory Studio paper lockup" />
            <div className="brand-lockup">
              <span className="eclipse huge" />
              <b>
                still
                <br />
                theory
                <br />
                studio
              </b>
              <em>ideas begin on paper</em>
            </div>
            <p>We turn ideas into tangible work.</p>
          </section>
          <section id="studio" className="workshop-card">
            <div className="footer-label">WORKSHOP</div>
            <p>Every job starts on paper.</p>
            <ol>
              <li>
                <b>01</b> DRAW
              </li>
              <li>
                <b>02</b> MAKE
              </li>
              <li>
                <b>03</b> GROW
              </li>
            </ol>
            <a href="/studio">enter the workshop →</a>
            <a id="backstage" href="/backstage">
              go backstage →
            </a>
          </section>
        </div>

        <section id="connect" className="connect-card">
          <div className="footer-label">CONNECT</div>
          <a className="contact-mail" href="mailto:hello@stilltheory.studio">
            hello@stilltheory.studio
          </a>
          <div className="contact-row">
            <span>LOS ANGELES · EVERYWHERE</span>
            <b>open for new projects</b>
            <a href="https://instagram.com" target="_blank" rel="noreferrer">
              Instagram
            </a>
            <a href="https://linkedin.com" target="_blank" rel="noreferrer">
              LinkedIn
            </a>
          </div>
        </section>

        <div className="legal">
          <span>© 2026 STILL THEORY STUDIO — ALL RIGHTS RESERVED.</span>
          <div>
            <a href="/legal/privacy">Privacy</a> · <a href="/legal/terms">Terms</a>
          </div>
          <button
            type="button"
            onClick={() => {
              setRitual(false);
              requestAnimationFrame(() => setRitual(true));
            }}
          >
            crumple the day
          </button>
        </div>
      </footer>
    </main>
  );
}
