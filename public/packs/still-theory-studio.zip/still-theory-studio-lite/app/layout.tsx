import type { Metadata } from "next";
import { headers } from "next/headers";
import "./globals.css";

export async function generateMetadata(): Promise<Metadata> {
  const requestHeaders = await headers();
  const host = requestHeaders.get("host") || "localhost:3000";
  const protocol = host.includes("localhost") ? "http" : "https";
  const image = `${protocol}://${host}/og.png`;

  return {
    title: {
      default: "Still Theory Studio — Ideas begin on paper",
      template: "%s — Still Theory Studio",
    },
    description:
      "A creative studio told through a scroll-driven paper-cut brand film: identity, software and social — cut, folded and rebuilt by hand.",
    icons: { icon: "/favicon.svg" },
    openGraph: {
      title: "Still Theory Studio — Ideas begin on paper",
      description: "Identity, software and social — cut, folded and rebuilt by hand.",
      type: "website",
      siteName: "Still Theory Studio",
      images: [{ url: image, width: 1200, height: 630, alt: "Still Theory Studio" }],
    },
    twitter: {
      card: "summary_large_image",
      title: "Still Theory Studio — Ideas begin on paper",
      description: "Identity, software and social — cut, folded and rebuilt by hand.",
      images: [image],
    },
  };
}

export const viewport = {
  themeColor: "#16130f",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,400;12..96,600;12..96,700;12..96,800&family=Caveat:wght@600;700&family=Hanken+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
