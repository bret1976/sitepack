type NavKey = "film" | "work" | "studio" | "backstage";

export function SiteHeader({ active }: { active?: NavKey }) {
  return (
    <header className="topbar topbar-static" data-brand="Still Theory Studio">
      <a className="topmark" href="/" aria-label="Still Theory Studio home">
        <span className="eclipse" aria-hidden="true" />
        <b>still theory studio</b>
      </a>
      <nav aria-label="site navigation">
        <a className={active === "film" ? "on" : undefined} href="/">
          film
        </a>
        <i>·</i>
        <a className={active === "work" ? "on" : undefined} href="/work">
          work
        </a>
        <i>·</i>
        <a className={active === "studio" ? "on" : undefined} href="/studio">
          studio
        </a>
        <i>·</i>
        <a className={active === "backstage" ? "on" : undefined} href="/backstage">
          backstage
        </a>
        <i>·</i>
        <span className="langs">
          <b>en</b>
          <em>tr</em>
        </span>
      </nav>
    </header>
  );
}
