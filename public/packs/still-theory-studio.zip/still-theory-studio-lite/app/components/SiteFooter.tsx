export function SiteFooter() {
  return (
    <footer className="page-footer">
      <div className="page-footer-inner">
        <a className="topmark" href="/" aria-label="Still Theory Studio">
          <span className="eclipse" />
          <b>still theory studio</b>
        </a>
        <div className="page-footer-links">
          <a href="/work">work</a>
          <a href="/studio">studio</a>
          <a href="/backstage">backstage</a>
          <a href="mailto:hello@stilltheory.studio">hello@stilltheory.studio</a>
        </div>
        <div className="legal legal-inline">
          <span>© 2026 STILL THEORY STUDIO — ALL RIGHTS RESERVED.</span>
          <div>
            <a href="/legal/privacy">Privacy</a> · <a href="/legal/terms">Terms</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
