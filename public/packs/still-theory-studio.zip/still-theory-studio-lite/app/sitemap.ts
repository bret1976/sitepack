import type { MetadataRoute } from "next";

const BASE = "https://still-theory-studio.vercel.app";

const paths = ["/", "/studio", "/work", "/backstage", "/legal/privacy", "/legal/terms"];

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  return paths.map((path, i) => ({
    url: `${BASE}${path === "/" ? "" : path}`,
    lastModified: now,
    changeFrequency: i === 0 ? "weekly" : "monthly",
    priority: i === 0 ? 1 : path.startsWith("/legal") ? 0.3 : 0.7,
  }));
}
