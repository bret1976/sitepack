/**
 * Optional D1 helper for Cloudflare/vinext hosts.
 * Not used by the public Still Theory Studio marketing site.
 */
import { drizzle } from "drizzle-orm/d1";
import * as schema from "./schema";

type D1Like = {
  prepare: (query: string) => unknown;
};

function getCloudflareDb(): D1Like | null {
  try {
    // Dynamic access so standard Next.js builds (Vercel/Railway) don't require cloudflare:workers
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const workers = (globalThis as { Cloudflare?: { env?: { DB?: D1Like } } }).Cloudflare;
    return workers?.env?.DB ?? null;
  } catch {
    return null;
  }
}

export function getDb() {
  const DB = getCloudflareDb();
  if (!DB) {
    throw new Error(
      "Database binding is unavailable. This marketing site does not require a database.",
    );
  }
  return drizzle(DB as never, { schema });
}
