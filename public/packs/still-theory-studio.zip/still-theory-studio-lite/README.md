# Still Theory Studio

Paper-craft brand site for **Still Theory Studio** — a scroll-scrubbed brand film and multipage studio site (inspired by the Ellusion Creative paper aesthetic).

**Ideas begin on paper.**

## Live

Deployed on **Railway** (chosen over Vercel for ~300MB of film frame assets).

**Live:** https://still-theory-studio-production.up.railway.app

## Stack

- Next.js 16 (App Router) + React 19
- High-density WebP film sequences under `public/assets/film`
- Optional vinext/Cloudflare path still available via `npm run dev:vinext`

## Pages

| Route | Purpose |
| --- | --- |
| `/` | Intro + 7-beat scroll film + footer |
| `/work` | Selected work |
| `/studio` | Workshop |
| `/backstage` | How the film was built |
| `/legal/privacy` | Privacy |
| `/legal/terms` | Terms |

## Local

```bash
npm install
npm run dev      # http://localhost:3000
npm run build
npm start
```

Requires Node.js `>=22.13.0`.

## Deploy (Railway)

```bash
railway link   # or railway init
railway up
railway domain
```

Build: `npm run build` · Start: `npm run start` (uses `$PORT`).

## Brand

- Name: **Still Theory Studio**
- Contact: `hello@stilltheory.studio`
