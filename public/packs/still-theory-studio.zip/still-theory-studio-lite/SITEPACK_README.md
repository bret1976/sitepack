# Still Theory Studio — SitePack

**Demo:** https://still-theory-studio.vercel.app  
**Pack ID:** `still-theory-studio`  
**Source:** repo:bret1976/still-theory-studio  
**Stack notes:** Next.js / Vite hybrid, film-studio portfolio

## What's included
- Full project source (sanitized — no live secrets)
- LICENSE.txt (personal + client work OK; no resale as competing packs)
- This README

## How to run
```bash
npm install && npm run dev
```

## Notes
- Replace any placeholder API keys / Firebase config with your own.
- Client/demo branding is illustrative — rebrand before shipping.
- Packaged for SitePack (sitepack). Motionsites-style browse → buy → unlock ZIP.
