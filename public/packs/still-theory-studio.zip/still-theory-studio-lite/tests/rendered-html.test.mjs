import assert from "node:assert/strict";
import { readFile, access } from "node:fs/promises";
import test from "node:test";

const templateRoot = new URL("../", import.meta.url);

async function render(path = "/") {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}-${path}`);
  const { default: worker } = await import(workerUrl.href);

  return worker.fetch(
    new Request(`http://localhost${path}`, {
      headers: { accept: "text/html" },
    }),
    {
      ASSETS: {
        fetch: async () => new Response("Not found", { status: 404 }),
      },
    },
    {
      waitUntil() {},
      passThroughOnException() {},
    },
  );
}

test("homepage brands Still Theory Studio and serves the film shell", async () => {
  const response = await render("/");
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);

  const html = await response.text();
  assert.match(html, /Still Theory Studio/i);
  assert.doesNotMatch(html, /Ellusion Creative|Elusive Creative|ellusion\b/i);
  assert.match(html, /still theory studio/i);
  assert.match(html, /Ideas begin on paper/i);
  assert.match(html, /hello@stilltheory\.studio/i);
  assert.match(html, /film\/frames|film-layer|STILL THEORY STUDIO/i);
});

test("work, studio and backstage routes render with brand name", async () => {
  for (const path of ["/work", "/studio", "/backstage"]) {
    const response = await render(path);
    assert.equal(response.status, 200, `${path} should return 200`);
    const html = await response.text();
    assert.match(html, /Still Theory Studio|still theory studio/i);
    assert.doesNotMatch(html, /Ellusion Creative|Elusive Creative/i);
  }
});

test("source keeps Still Theory Studio naming and multipage routes", async () => {
  const [page, layout, work, studio, backstage, packageJson] = await Promise.all([
    readFile(new URL("../app/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/layout.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/work/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/studio/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/backstage/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../package.json", import.meta.url), "utf8"),
  ]);

  assert.match(layout, /Still Theory Studio/);
  assert.match(page, /still theory studio/i);
  assert.match(page, /STILL THEORY STUDIO/);
  assert.match(work, /Still Theory Studio/);
  assert.match(studio, /Still Theory Studio/);
  assert.match(backstage, /Still Theory Studio/);
  assert.match(packageJson, /"name": "still-theory-studio"/);

  await Promise.all([
    access(new URL("app/legal/privacy/page.tsx", templateRoot)),
    access(new URL("app/legal/terms/page.tsx", templateRoot)),
    access(new URL("public/assets/film/frames/01-logo/0001.webp", templateRoot)),
    access(new URL("public/assets/film/frames-portrait/01-logo/0001.webp", templateRoot)),
    access(new URL("public/assets/film/manifest.json", templateRoot)),
  ]);
});
