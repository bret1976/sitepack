# 6Frame Rates — SitePack

**Demo:** https://www.6framerates.com  
**Pack ID:** `6frame-rate-website`  
**Source:** repo:bret1976/6frame-rate-website  
**Stack notes:** React + Vite + Firebase rates site

## What's included
- Full project source (sanitized — no live secrets)
- LICENSE.txt (personal + client work OK; no resale as competing packs)
- This README

## How to run
```bash
npm install && npm run dev
```

## Notes
- Replace any placeholder API keys / Firebase config with your own.
- Client/demo branding is illustrative — rebrand before shipping.
- Packaged for SitePack (sitepack). Motionsites-style browse → buy → unlock ZIP.
