# Starling — SitePack

**Demo:** https://starling-production-5190.up.railway.app  
**Pack ID:** `starling`  
**Source:** repo:bret1976/starling  
**Stack notes:** Python FastAPI local-business SaaS

## What's included
- Full project source (sanitized — no live secrets)
- LICENSE.txt (personal + client work OK; no resale as competing packs)
- This README

## How to run
```bash
pip install -r requirements.txt && PYTHONPATH=. uvicorn app.main:app --reload --port 8790
```

## Notes
- Replace any placeholder API keys / Firebase config with your own.
- Client/demo branding is illustrative — rebrand before shipping.
- Packaged for SitePack (sitepack). Motionsites-style browse → buy → unlock ZIP.
