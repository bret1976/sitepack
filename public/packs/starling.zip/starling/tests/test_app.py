import os
import tempfile
import uuid
from pathlib import Path

os.environ["STARLING_DB"] = str(Path(tempfile.mkdtemp()) / "t.db")
os.environ.pop("SMTP_HOST", None)
os.environ.pop("TWILIO_ACCOUNT_SID", None)

from fastapi.testclient import TestClient

from app.db import init
from app.main import app

init()
c = TestClient(app)


def signup():
    r = c.post(
        "/api/auth/signup",
        json={
            "name": "Test Owner",
            "email": f"owner-{uuid.uuid4().hex[:10]}@biz.test",
            "password": "password12",
            "business": "Test Dental",
            "industry": "dental",
            "city": "Austin",
            "state": "TX",
        },
    )
    assert r.status_code == 200, r.text
    return r.json()["user"]


def test_health():
    r = c.get("/api/health")
    assert r.json()["ok"] is True
    assert r.json()["product"] == "Starling"
    assert "delivery" in r.json()

    assert r.json().get("quiet_hours") == "quiet-hours-v1"
    assert r.json().get("nap_diff") == "nap-diff-v1"


def test_no_seed_users():
    r = c.post("/api/auth/login", json={"email": "demo@northside.dental", "password": "demo1234"})
    assert r.status_code == 401


def test_signup_empty_dashboard():
    signup()
    d = c.get("/api/dashboard").json()
    assert d["location"]["name"] == "Test Dental"
    assert d["stats"]["reviews"] == 0
    assert c.get("/api/customers").json()["customers"] == []
    assert c.get("/api/reviews").json()["reviews"] == []


def test_review_funnel_creates_live_link():
    signup()
    cid = c.post("/api/customers", json={"name": "Jordan Hale", "email": "jordan@example.com", "phone": "5125550100"}).json()["id"]
    sent = c.post("/api/review-requests", json={"customer_id": cid, "channel": "email"}).json()
    assert sent["link"].startswith("http")
    assert sent["token"]
    assert sent["sent"] is False
    assert "SMTP" in (sent["delivery"] or {}).get("error", "")
    token = sent["token"]
    pub = c.post(f"/api/public/review/{token}", json={"rating": 5, "text": "Loved it"})
    assert pub.status_code == 200
    assert pub.json()["public"] is True
    reviews = c.get("/api/reviews").json()["reviews"]
    assert any(r["text"] == "Loved it" for r in reviews)


def test_low_star_private_inbox():
    signup()
    cid = c.post("/api/customers", json={"name": "Sam", "email": "sam@example.com"}).json()["id"]
    token = c.post("/api/review-requests", json={"customer_id": cid, "channel": "email"}).json()["token"]
    c.post(f"/api/public/review/{token}", json={"rating": 2, "text": "Waited forever"})
    inbox = c.get("/api/inbox").json()["threads"]
    assert any(t["channel"] == "review" for t in inbox)


def test_widget_to_inbox():
    signup()
    slug = c.get("/api/dashboard").json()["location"]["slug"]
    r = c.post("/api/widget/chat", json={"slug": slug, "name": "Alex", "body": "Hours today?"})
    assert r.status_code == 200
    names = [t["name"] for t in c.get("/api/inbox").json()["threads"]]
    assert "Alex" in names


def test_form_to_inbox():
    signup()
    form = c.post("/api/forms", json={"name": "Contact", "fields": "name,message"}).json()
    assert form["url"].startswith("/f/")
    r = c.post(f"/api/public/form/{form['slug']}", json={"payload": {"name": "Pat", "message": "Need a cleaning"}})
    assert r.status_code == 200
    assert any(t["channel"] == "form" for t in c.get("/api/inbox").json()["threads"])


def test_listings_scan_real_osm():
    signup()
    c.patch("/api/location", json={"name": "Texas State Capitol", "address": "1100 Congress Ave", "city": "Austin", "state": "TX", "zip": "78701"})
    r = c.post("/api/listings/sync")
    assert r.status_code == 200, r.text
    dirs = [l["directory"] for l in r.json()["listings"]]
    assert "OpenStreetMap" in dirs
    assert "Google Business" in dirs


def test_ask_review_one_step():
    signup()
    d = c.post("/api/ask-review", json={"name": "Jordan Hale", "email": "jordan@example.com"}).json()
    assert d["link"].startswith("http")
    assert d["token"]
    assert d["sent"] is False
    home = c.get("/api/dashboard").json()
    assert home["stats"]["requests"] == 1
    assert home["pending"]
    token = d["token"]
    c.post(f"/api/public/review/{token}", json={"rating": 5, "text": "Loved it"})
    home = c.get("/api/dashboard").json()
    assert home["stats"]["reviews"] == 1
    assert any(r["text"] == "Loved it" for r in home["recent"])


def test_plan_gate_social():
    signup()
    r = c.get("/api/social")
    assert r.status_code == 402
    c.post("/api/location/plan", json={"plan": "growth"})
    assert c.get("/api/social").status_code == 200

def test_public_insights_themes():
    r = c.post(
        "/api/public/insights",
        json={"text": "5 - Dr. Patel was gentle and the front desk was friendly\n2 - Waited over an hour and nobody called back\n1 - Charged me twice, receptionist was rude"},
    )
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["with_text"] == 3
    labels = {a["aspect"] for a in d["aspects"]}
    assert {"staff", "wait", "price"} <= labels
    assert d["fix_first"] in {"staff", "wait", "price", "communication"}
    assert c.post("/api/public/insights", json={"text": "  "}).status_code == 400


def test_dashboard_insights_requires_login_and_reads_reviews():
    fresh = TestClient(app)
    assert fresh.get("/api/insights").status_code == 401
    user = signup()
    from app.db import connect as _connect
    con = _connect()
    con.execute(
        "INSERT INTO reviews (location_id, source, rating, text, public, created_at) VALUES (?,?,?,?,?,?)",
        (user["location_id"], "starling", 5, "Great work but they charged me twice.", 1, 1.0),
    )
    con.commit()
    con.close()
    r = c.get("/api/insights")
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["reviews"] == 1
    assert d["mismatches"] and d["mismatches"][0]["rating"] == 5
    assert c.get("/review-analyzer").status_code == 200


def test_health_local_reply_pack():
    d = c.get("/api/health").json()
    assert d["local_reply"] == "instant-pack-v1"


def test_public_local_reply_praise_and_recovery():
    praise = c.post(
        "/api/public/local-reply",
        json={
            "business": "Northside Dental",
            "industry": "dental",
            "rating": 5,
            "text": "Dr. Patel was gentle and the front desk was so friendly!",
            "customer": "Jordan Hale",
        },
    )
    assert praise.status_code == 200, praise.text
    p = praise.json()
    assert p["ok"] is True
    assert p["source"] == "instant-pack-v1"
    assert p["band"] == "praise"
    assert p["metered"] is False
    assert "Jordan" in p["text"]
    assert "Northside Dental" in p["text"]
    assert "staff" in p["aspects"]

    bad = c.post(
        "/api/public/local-reply",
        json={
            "business": "Northside Dental",
            "industry": "dental",
            "rating": 1,
            "text": "Waited over an hour and nobody called back about billing.",
            "customer": "Sam",
        },
    )
    assert bad.status_code == 200, bad.text
    b = bad.json()
    assert b["band"] == "recovery"
    assert b["metered"] is False
    assert "Sam" in b["text"]
    assert set(b["aspects"]) & {"wait", "communication", "price"}


def test_send_local_saves_reply_without_ai_meter():
    user = signup()
    from app.db import connect as _connect

    con = _connect()
    cid = con.execute(
        "INSERT INTO customers (location_id, name, phone, email) VALUES (?,?,?,?)",
        (user["location_id"], "Alex Kim", "", "alex@example.com"),
    ).lastrowid
    rid = con.execute(
        "INSERT INTO reviews (location_id, customer_id, source, rating, text, public, created_at) VALUES (?,?,?,?,?,?,?)",
        (user["location_id"], cid, "starling", 2, "Waited forever and the receptionist was rude.", 1, 1.0),
    ).lastrowid
    con.commit()
    con.close()
    r = c.post(f"/api/reviews/{rid}/send-local")
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["source"] == "instant-pack-v1"
    assert d["metered"] is False
    # local-reply SELECT * FROM reviews has no customer_name join; guest fallback is fine,
    # but business name must appear and reply must persist.
    assert "Alex" in d["text"] and "Test Dental" in d["text"]
    reviews = c.get("/api/reviews").json()["reviews"]
    saved = next(x for x in reviews if x["id"] == rid)
    assert saved["reply"] == d["text"]

if __name__ == "__main__":
    failed = 0
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print("ok", name)
            except Exception as e:
                failed += 1
                print("FAIL", name, type(e).__name__, e)
    raise SystemExit(failed)


def test_health_nap_diff_pack():
    d = c.get("/api/health").json()
    assert d["nap_diff"] == "nap-diff-v1"
    assert d["local_reply"] == "instant-pack-v1"


def test_public_nap_diff_formatting_vs_mismatch():
    # Same phone, different formatting → formatting overall when other fields match
    fmt = c.post(
        "/api/public/nap-diff",
        json={
            "name": "Northside Dental",
            "address": "123 Main Street",
            "city": "Austin",
            "state": "TX",
            "zip": "78701",
            "phone": "(512) 555-0100",
            "observed_name": "Northside Dental",
            "observed_address": "123 Main St",
            "observed_city": "Austin",
            "observed_state": "TX",
            "observed_zip": "78701",
            "observed_phone": "512-555-0100",
        },
    )
    assert fmt.status_code == 200, fmt.text
    f = fmt.json()
    assert f["ok"] is True
    assert f["pack"] == "nap-diff-v1"
    assert f["overall"] == "formatting"
    assert f["nap_match"] == 1
    assert f["fields"]["phone"]["status"] == "formatting"
    assert f["fields"]["address"]["status"] == "formatting"

    bad = c.post(
        "/api/public/nap-diff",
        json={
            "name": "Northside Dental",
            "address": "123 Main Street, Austin, TX 78701",
            "phone": "5125550100",
            "observed_name": "Northside Dental",
            "observed_address": "456 Oak Avenue, Austin, TX 78701",
            "observed_phone": "5125550199",
        },
    )
    assert bad.status_code == 200, bad.text
    b = bad.json()
    assert b["overall"] == "mismatch"
    assert b["nap_match"] == 0
    assert b["fields"]["address"]["status"] == "mismatch"
    assert b["fields"]["phone"]["status"] == "mismatch"
    assert "mismatch" in (b.get("fix_hint") or "").lower() or "Real mismatch" in (b.get("fix_hint") or "")

    assert c.post("/api/public/nap-diff", json={}).status_code == 400


def test_listings_nap_diff_requires_login_and_grades():
    fresh = TestClient(app)
    assert fresh.post("/api/listings/nap-diff", json={"observed_name": "X"}).status_code == 401
    signup()
    # set phone + address for a real compare
    c.patch(
        "/api/location",
        json={
            "name": "Test Dental",
            "address": "1100 Congress Ave",
            "city": "Austin",
            "state": "TX",
            "zip": "78701",
            "phone": "5125550100",
        },
    )
    r = c.post(
        "/api/listings/nap-diff",
        json={
            "observed_name": "Test Dental",
            "observed_address": "1100 Congress Avenue",
            "observed_city": "Austin",
            "observed_state": "TX",
            "observed_zip": "78701",
            "observed_phone": "+1 (512) 555-0100",
            "directory": "Yelp",
        },
    )
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["pack"] == "nap-diff-v1"
    assert d["overall"] == "formatting"
    assert d["nap_match"] == 1
    assert d["directory"] == "Yelp"
